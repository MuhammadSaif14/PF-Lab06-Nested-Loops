#include<stdio.h>
int main()
{
	int num=2, count=0, i, sum, first;
	
	while(count < 4)
	{
		sum=0;
		for(i=1;i<=num/2; i++)
		{
			if(num % i == 0)
				sum += i;
		}
		if(sum == num)
			{
				printf("%d is a perfect number\n", num);
				first = 1;
				
				for(i=1;i<=num/2;i++)
				{
					if(num % i ==0)
					{
						if(!first)
							printf("+");
						printf("%d", i);
						first = 0;
					}
				}
				printf("=%d\n", num);
				count++;
			}
		
		num++;
	}
	
	return 0;
}
