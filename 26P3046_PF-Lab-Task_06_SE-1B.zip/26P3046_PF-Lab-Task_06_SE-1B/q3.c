#include<stdio.h>
int main()
{
	int n, k, i;
	double x, s=0, power, fact;
	
	printf("Enter the value for n: ");
	scanf("%d", &n);
	printf("Enter the value for x: ");
	scanf("%lf", &x);
	
	for(k=0;k<=n;k++)
	{
		power=1;
		fact=1;
		
		for(i=1;i<=k;i++)
		{
			power = power * x;
			fact = fact * i;
		}
		s = s + power / fact;
	}
	printf("s = %.1f\n", s);
	
	return 0;
}
