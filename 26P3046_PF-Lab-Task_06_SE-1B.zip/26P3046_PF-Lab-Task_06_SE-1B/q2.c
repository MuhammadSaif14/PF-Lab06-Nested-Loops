#include<stdio.h>
int main()
{
	char symbol;
	int g, h, i,j;
	
	printf("Enter symbol: ");
	scanf("%c", &symbol);
	
	for(g=1;g<=5-1;g++)
	{
		for(h=1;h<=g;h++)
		{
			printf("%c", symbol);
		}
		printf("\n");
	}
	
	for(i=1;i<=5;i++)
	{
		for(j=5;j>=i;j--)
		{
			printf("%c", symbol);
		}
		printf("\n");
	}
	
	
	return 0;
}
